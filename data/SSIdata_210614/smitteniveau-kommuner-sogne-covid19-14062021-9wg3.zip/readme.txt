Dette dokument beskriver indholdet af zip-filen. Variabelnavnene, som beskrives nedenfor, refererer til søjlenavne medmindre andet er beskrevet. 

Generelt:
Filerne bliver opdateret hver dag og i denne forbindelse kan tidsserier også ændre sig tilbage i tiden, hvis nyere data foreligger. Derfor anbefales det altid at benytte det senest tilgængelige data og for så vidt muligt, ikke at gemme filer og lave tidsserier på basis af gamle filer.
Såfremt en kommune eller et sogn bliver nedlukket, ændres variablen ”Status for automatisk nedlukning” i datafilerne til ”Nedlukket”. I så fald skal kommunen iværksatte nedlukning af kommunen/sognet fra og med den følgende dag. Når en nedlukket kommune eller et nedlukket sogn skal genåbnes, ændres variablen ”Status for automatisk nedlukning” til en af de øvrige kategorier. I så fald vil genåbningen kunne foretages samme dag, som filen med den ændrede status er offentliggjort.
------------------------------------------------------

Fil 1: Kommunedata (filnavn: testjusterede_incidenser_kommuner.csv)

Modellen for nedlukning af kommunerne er baseret på, hvorvidt der på én og samme dage i en kommune forekommer en testjusteret incidens per 100.000 indbygger (se uddybende forklaring af testjusteret incidens nedenfor) på 300 eller derover og 20 eller flere nye registrerede smittetilfælde. I det tilfælde vil kommunen skulle påbyde en kommunal nedlukning.
Nedlukkede kommuner kan genåbne igen, når det i 7 dage i træk ikke på samme dag har været over de to grænseværdier. Eksempel: En kommune, der først i tre dage i træk har været under grænseværdien for det testjusterede incidenstal kan altså genåbne, hvis det i de følgende fire dage er under grænseværdien for antallet af nye registrerede smittetilfælde, også selvom det testjusterede incidenstal i de fire følgende dage skulle overstige grænseværdien, og det samme er gældende vice versa med først antal registrerede tilfælde under grænseværdien, efterfulgt at en testjusteret incidens under grænseværdien.
Filen viser den testjusterede incidens og antallet af nye registrerede smittetilfælde pr. dags dato samt for de forudgående 6 dage, altså i alt for 7 sammenhængende dage.

Generelt om beregning af den testjusteret incidens:
Det gælder generelt, at hvis der testes mere (foretages flere tests) i en kommune end i en anden kommune, vil der sandsynligvis blive fundet flere smittede i den kommune, hvor der er flest indbyggere, der bliver testet, også selvom det faktiske smittetryk er ensartet i de to kommuner. Dette medfører at incidensen bliver højere i den kommune, hvor flest lader sig teste, hvis man sammenlignede to kommuner, hvor smitteforekomsten var ens. For at sikre et ensartet sammenligningsgrundlag mellem incidensen på tværs af kommunerne beregner ekspertgruppen for matematisk modellering af covid-19 under Statens Serum Institut derfor den såkaldte testjusterede incidens for hver kommune, hvori der er taget højde for forskelle i niveauet af testning i kommunerne (se ekspertgruppen for matematisk modellerings beskrivelse der hvor du downloader nærværende filer).
Den testjusterede incidens er beregnet alene på baggrund af PCR-tests.
Den testjusterede incidens for en given dag er beregnet på tests, der er foretaget over en 7-døgns periode. Den anvendte data er trunkeret, hvilket betyder at incidenstallet er beregnet på baggrund af de tests, der blev gennemført fra og med tre til ni dage forud for opgørelsesdatoen (i alt 7 dage). Eksempel: Den testjusterede incidens for datoen 28. maj 2021 vil således være baseret på data, der er trunkeret med tre dage, således at datagrundlaget består af tests, der er foretaget fra og med den 25. maj til og med den 19. maj (begge dage inklusive). Den testjusterede incidens er trunkeret for at sikre det mest fuldkomne datagrundlag. Det skyldes at der er en forsinkelse på prøvesvaret fra prøven er taget til den er blevet analyseret og registreret. 
OBS: Den 28. maj 2021 er proceduren for datatrunkeringen blevet ændret, således at data trunkeres med 3 dage, fremfor med 2 dage, hvilket tidligere har været anvendt. Af samme grund vil den testjusterede incidens i kommunerne den 28. maj 2021 kun være marginalt forskellig fra den testjusterede incidens pr. d. 27. maj 2021. Ændringen er foretaget for at muliggøre, at de testjusterede incidenser i kommunerne og antallet af nye registrerede smittetilfælde i kommunerne er opgjort på det samme datagrundlag. Det er således alene muligt at opgøre antallet af nye registrerede smittetilfælde ved brug af 3 dages datatrunkering. 
OBS: Den 28. maj er grænseværdien for den testjusterede incidens ændret fra 250 til 300 og der er indført en ny grænseværdi for minimum 20 nye registrerede smittetilfælde i kommunen. For nedlukkede kommuner pr. 28. maj 2021 vil det gælde, at de kan genåbne, såfremt de i 7 dage i træk ikke på samme dag har været over begge grænseværdier. Dette inkluderer også dagene forud for d. 28. maj. 
Det testjusterede incidenstal for en pågældende dag bliver ikke genberegnet i de efterfølgende dage, hvorfor tal for den testjusterede incidens fra tidligere dage bliver videreført i modellen. 

Generelt beregning af antallet af nye registrerede smittetilfælde i kommunen:
Antal nye registrerede smittetilfælde i kommunen er beregnet over en 7-døgns periode på baggrund af trunkerede data, hvilket betyder, at datagrundlaget er baseret på test, der har prøvedato fra og med 3 til 9 dage (begge dage inklusive) forud for opgørelsesdagen. Dette er gjort for at sikre det mest fuldkomne datagrundlag. 
Der indgår alene PCR-test i datagrundlaget.

Beskrivelse af variable:
Kommune: angiver kommunen
Kommunekode: angiver kommunekoden
Indbyggertal i kommunen: angiver indbyggertallet i kommunen pr. 1. kvartal 2020 i henhold til opgørelse af Danmarks Statistik.
Testjusteret incidens pr. [dato]: angiver den testjusterede incidens beregnet for den pågældende dato
Antal nye smittede i kommunen pr. [dato]: angiver antallet af nye registrerede smittetilfælde beregnet for den pågældende dato
Status for automatisk nedlukning: angiver hvorvidt kommunen er nedlukket (de to grænseværdier er overskredet på samme dag indenfor de seneste 7 dage), hvorvidt kommunen har et højt incidenstal, men ikke højt nok til at være omfattet af nedlukning (den testjusterede incidens er mellem 150 og 300 pr. dags dato og kommunen er ikke nedlukket), eller hvorvidt kommunen har et lavt incidenstal og ikke er omfattet af nedlukning (den testjusterede incidens er mellem 0 og 150 og kommunen er ikke nedlukket).
Påbegyndelsesdato for seneste automatiske nedlukning af kommunen: angiver den dato, hvor kommunen blev omfattet af en aktuel nedlukning. 
Antal dage i træk med opfyldt genåbningskriterie: angiver antallet af dage i træk kommunen har været under minimum én af de to grænseværdier. 

------------------------------------------------------

Fil 2: Sognedata (filnavn:  sognedata_nedlukning.csv)

Modellen for nedlukning af sognene er baseret på, hvorvidt der på en og samme dag i et sogn forekommer en incidens pr. 100.000 indbygger på 600 eller derover, 20 eller flere nye registrerede smittetilfælde og en positivprocent på 3 eller derover. I det tilfælde vil sognet stå ovenfor en nedlukning.
Et nedlukket sogn kan genåbne, når det i 7 dage i træk ikke på samme dag har været over alle tre grænseværdier. Eksempel: Et sogn, der i tre dage i træk har været under grænseværdien for incidenstallet kan altså genåbne, hvis det i de følgende fire dage er under grænseværdien for en af de to andre parametre (positivprocenten eller antallet af smittede), også selvom incidenstallet i de fire følgende dage skulle overstige grænseværdien. 
Filen viser incidensen, antallet af nye registrerede smittetilfælde og positivprocenten opgjort pr. dags dato samt for de forudgående 6 dage, altså i alt for 7 sammenhængende dage. 

Generelt om datagrundlaget for beregning af incidens, antallet af nye registrerede smittetilfælde og positivprocent i sognene:
Både incidens, antal nye registrerede smittetilfælde og positivprocenten er beregnet over en 7 døgnsperiode på baggrund af trunkerede data, hvilket betyder, at datagrundlaget er baseret på test, der er gennemført fra og med 3 til 9 dage (begge dage inklusive) forud for opgørelsesdagen. Dette er gjort for at sikre det mest fuldkomne datagrundlag. 
Der indgår alene PCR-test i datagrundlaget.
I det tilfælde, at der er sogne, hvor færre end 10 indbyggerne i sognet ikke har ladet sig teste i løbet af 7-døgns-opgørelsesperioden, vil sognets værdier for incidens, antal smittede og positivprocent være beregnet ud fra et princip om, at antal smittede og antal testede maksimalt kan antage en værdi, der ligger 10 under indbyggertallet i sognet. Denne diskretionering af sognene er udført i henhold til at beskytte personhenførbare oplysninger.
OBS: Den 28. maj er grænseværdien for incidensen ændret fra 500 til 600 og grænseværdien for positivprocenten ændret fra 2,5 til 3. For nedlukkede sogne pr. 28. maj 2021 vil det gælde, at de kan genåbne, såfremt de i 7 dage i træk ikke på samme dag har været over alle grænseværdier. Dette inkluderer også dagene forud for d. 28. maj. 

Beskrivelse af variable:
Sogn: angiver sognet
Kommune: angiver kommunen sognet ligger i (et sogn kan ligge i flere kommuner. I det tilfælde er alle kommuner angivet)
Indbyggertal i sognet: angiver indbyggertallet i sognet pr. 1. kvartal 2020 i henhold til opgørelse af Danmarks Statistik.
Incidens i sogn beregnet pr. [dato]: angiver incidensen beregnet for den pågældende dato.
Antal nye smittede i sogn pr. [dato]: angiver antallet af nye registrerede smittetilfælde beregnet for den pågældende dato.
Positivprocent i sogn beregnet pr. [dato]: angiver positivprocenten beregnet for den pågældende dato.
Status for automatisk nedlukning: Angiver hvorvidt sognet er nedlukket (de tre grænseværdier er overskredet indenfor de seneste 7 dage). 
Påbegyndelsesdato for seneste automatiske nedlukning af sognet: angiver den dato, hvor sognet blev omfattet af en aktuel nedlukning.
Antal dage i træk med opfyldt genåbningskriterie: angiver antallet af dage i træk et sogn har været under minimum én af de tre grænseværdier. 


